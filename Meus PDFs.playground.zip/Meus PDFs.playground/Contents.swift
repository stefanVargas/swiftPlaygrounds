import UIKit
import PDFKit
import PlaygroundSupport

// Classe que controla a view do PDF aberto
class ProfileViewController: UIViewController {
    
    public var name: String?
    public var backgroundColor: UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    var pdfdocument: PDFDocument?
    
    override func loadView() {
        super.loadView()
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        self.title = name
        
        //If da abertura conforme a apostila
        if #available(iOSApplicationExtension 11.0, *){
            
            var pdfview: PDFView!
            
            
            pdfview = PDFView(frame: CGRect(x: 0, y: 0, width: 450, height: 600))
            
            pdfview.document = pdfdocument
            pdfview.displayMode = PDFDisplayMode.singlePageContinuous
            pdfview.autoScales = true
            
            
            view.addSubview(pdfview)
            
        }
        else {
            print("PDFKit is not supported for versions before iOS 11.0")
        }
        
    }
}
// Classe do estilo e posição dos botoes (thumbnails) da Collection View
class MyCollectionViewCell: UICollectionViewCell {
    
    
    public let nameLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = NSTextAlignment.justified
        label.backgroundColor = UIColor.white.withAlphaComponent(0.75)
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.black
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    public var backImageView: UIImageView = {
        let imageView = UIImageView()
        
        return imageView
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(nameLabel)
        backImageView  = UIImageView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        backImageView.contentMode = UIViewContentMode.scaleAspectFit
        
        self.addSubview(backImageView)
        
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.centerXAnchor.constraint(equalTo: backImageView.centerXAnchor).isActive = true
        nameLabel.centerYAnchor.constraint(equalTo: backImageView.centerYAnchor, constant: 60).isActive = true
        
        nameLabel.widthAnchor.constraint(equalToConstant: 40)
        nameLabel.heightAnchor.constraint(equalToConstant: 60)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
// Nesta Classe a collection view é organizado, parametrizado na View
class CollectionViewController : UICollectionViewController, UIDocumentPickerDelegate, UINavigationControllerDelegate, UICollectionViewDelegateFlowLayout {
    
    // CollectionView DataSource = As arrays que serve de fonte para o Collection View
 
    private var nameList: [String] = ["pdf-sample", "pdf"]
    private var pdfDocUrlArr: [PDFDocument] = [PDFDocument(url: Bundle.main.url(forResource: "pdf-sample", withExtension: "pdf")!)!, PDFDocument(url: Bundle.main.url(forResource: "pdf", withExtension: "pdf")!)!]
    
    override func loadView() {
        super.loadView()
        self.title = "miPDFs"
        
            //cor de fundo
        self.collectionView?.backgroundColor = .lightGray
        self.collectionView?.register(MyCollectionViewCell.self, forCellWithReuseIdentifier: "PlayCell")
        
        // Botão Add na UIBAR
        let AddBtn = UIButton(type: .custom)
        AddBtn.setTitle("ADD", for: .normal)
        AddBtn.titleLabel?.font = UIFont (name: "helvetica", size: 17)
        AddBtn.setTitleColor(AddBtn.tintColor, for: .normal) 
        AddBtn.addTarget(self, action: #selector(myAddPdfFunction(sender:)), for: .touchUpInside)
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: AddBtn)
        
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return pdfDocUrlArr.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayCell", for: indexPath) as! MyCollectionViewCell
        
        cell.nameLabel.text = nameList[indexPath.row]
        
        if let page = pdfDocUrlArr[indexPath.row].page(at: 0){
            let thumbUnha = page.thumbnail(of: cell.bounds.size, for: PDFDisplayBox.cropBox)
            cell.backImageView.image = thumbUnha
        }
        return cell
    }
    // Função do tamanho da imagem do thumbmail
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: 90, height: 100)
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let profileCell = collectionView.cellForItem(at: indexPath) as! MyCollectionViewCell
        let profileViewController = ProfileViewController()
        
        profileViewController.name = nameList[indexPath.row]
        profileViewController.pdfdocument = pdfDocUrlArr[indexPath.row]
        navigationController?.pushViewController(profileViewController, animated: true)
    }
    
    //Coloca o PDF escolhido das Arrays de PDF e String(nome do PDF) e dá reload na View
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        
        
        let linkPicked = url as URL!
        let linkNoExt = linkPicked?.deletingPathExtension()
        let linkString: String = (linkNoExt?.lastPathComponent)!
        let linkPDF = PDFDocument(url: linkPicked!)!
        
        nameList.append(linkString)
        pdfDocUrlArr.append(linkPDF)
        
        DispatchQueue.main.async {
            self.collectionView?.reloadData()
            
            
        }
        dismiss(animated:true, completion: nil) 
    }
    
    //Função do Picker
    public func documentMenu(_ documentMenu:     UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self as! UIDocumentPickerDelegate
        present(documentPicker, animated: true, completion: nil)
    }
    // Fecha a View do DocumentPicker
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        
        dismiss(animated: true, completion: nil)
        
    }
    // Função @IBAction que adiciona o PDF
    @IBAction func myAddPdfFunction(sender:UIButton){
        
        let documentController: UIDocumentPickerViewController = UIDocumentPickerViewController(documentTypes: ["com.adobe.pdf"], in: UIDocumentPickerMode.import)
        documentController.delegate = self
        documentController.modalPresentationStyle = UIModalPresentationStyle.fullScreen
        self.present(documentController, animated: true, completion: nil)
    }
}

PlaygroundPage.current.liveView = UINavigationController(rootViewController:CollectionViewController(collectionViewLayout: UICollectionViewFlowLayout()))


