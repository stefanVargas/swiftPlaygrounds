//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport

class TimerViewController: UIViewController {
    
    
    var timerLabel: UILabel!
    
    
    
    var secs = 60
    var timer = Timer()
    var isRunning = false
    
    @IBAction func startButtonTap(_ sender: UIButton){
        runTimer()
        
    }
    
    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
    
    @IBAction func pauseButtonTap(_ sender: UIButton){
        
        
    }
    
    @IBAction func resetButtonTap(_ sender: UIButton){
        
        
    }
    
    @objc func updateTimer() {
        secs -= 1     //This will decrement(count down)the seconds.
        timerLabel.text = " \(secs)" //This will update the label.
    }
    
    override func loadView() {
        super.viewDidLoad()
        let view = UIView()
        view.backgroundColor = .darkGray
        self.view = view
        self.title = " iTimer "
        
        
        func myButtons(tag: Int, titler: String) -> UIButton {
            
            let button = UIButton()
            button.tag = tag
            button.backgroundColor = UIColor.black
            button.layer.cornerRadius = 35
            let Str = titler
            button.setTitle(Str, for: [])
            button.setTitleColor(UIColor.clear, for: UIControlState.highlighted)
            button.titleLabel!.font = UIFont(name: "Arial", size: 40)
            button.translatesAutoresizingMaskIntoConstraints = false
            return button
        }
        
        let startBut = myButtons(tag: 10, titler: "START")
        startBut.addTarget(self, action: #selector(startButtonTap(_:)), for: .touchUpInside);
        self.view.addSubview(startBut)
        
        
        NSLayoutConstraint.activate([
            
            
            startBut.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            startBut.trailingAnchor.constraint(equalTo: view.trailingAnchor , constant: -20),
            startBut.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.94),
            startBut.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.1),
        
        ])

        
    }
    
    
    
}

class StopWatchViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = " iStopWatch "
        
        func myButtons(tag: Int, titler: String) -> UIButton {
            
            let button = UIButton()
            button.tag = tag
            button.backgroundColor = UIColor.black
            button.layer.cornerRadius = 35
            let Str = titler
            button.setTitle(Str, for: [])
            button.setTitleColor(UIColor.clear, for: UIControlState.highlighted)
            button.titleLabel!.font = UIFont(name: "Arial", size: 40)
            button.translatesAutoresizingMaskIntoConstraints = false
            return button
        }
        
        
        
    }

    
    
}




class MyTabBarController: UITabBarController {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        let timeViewController = UINavigationController(rootViewController: TimerViewController())
        let tabBarItem1 = UITabBarItem(tabBarSystemItem: .search, tag: 1)
        timeViewController.tabBarItem  = tabBarItem1
        
        let stopViewController = StopWatchViewController()
        let tabBarItem2 = UITabBarItem(tabBarSystemItem: .downloads, tag: 1)
        stopViewController.tabBarItem  = tabBarItem2
        
        
        self.viewControllers = [timeViewController, stopViewController]
    }
    
}
//https://medium.com/ios-os-x-development/build-an-stopwatch-with-swift-3-0-c7040818a10f

PlaygroundPage.current.liveView = MyTabBarController()
