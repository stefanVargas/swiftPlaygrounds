import UIKit
import PlaygroundSupport

// Classe que controla a view das Foto aberta
class ProfileViewController: UIViewController {
    
    public var imagem: UIImage?
    public var backgroundColor: UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    
    override func viewDidLoad() {

        super.viewDidLoad()
        self.view.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        let image = imagem
        let imageView = UIImageView(image: image)
        
        imageView.frame = CGRect(x: 0, y: 0, width: 450, height: 500)
        
        view.addSubview(imageView)
        
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        
        // Layout
        NSLayoutConstraint.activate([
            imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 580),
            imageView.heightAnchor.constraint(equalToConstant: 700)
        
            ])
        
    }
}

// Classe do estilo e posição dos botões (mini-fotos) da Collection View
class MyCollectionViewCell: UICollectionViewCell {
    
    public var button: UIImageView = {  
        let button1 = UIImageView()

        
        return button1
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        button = UIImageView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        button.contentMode = UIViewContentMode.scaleAspectFit
        self.addSubview(button)
        
        }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// Nesta Classe a collection view é organizado, parametrizado na View 
class CollectionViewController : UICollectionViewController, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, UICollectionViewDelegateFlowLayout {
    
    // CollectionView DataSource = Fonte da CollectionView --> Arrey de Fotos
    
    let picker = UIImagePickerController()
    //View da Camera
    @IBOutlet weak var imagePicked: UIImageView!


    
     var photoList: [UIImage] = [#imageLiteral(resourceName: "IMG_0022.PNG"), #imageLiteral(resourceName: "IMG_0046.JPG"), #imageLiteral(resourceName: "IMG_0063.PNG"), #imageLiteral(resourceName: "IMG_0082.JPG"), #imageLiteral(resourceName: "IMG_0083.PNG"), #imageLiteral(resourceName: "IMG_0001.JPG"), #imageLiteral(resourceName: "IMG_0002.JPG"), #imageLiteral(resourceName: "IMG_0081.JPG"), #imageLiteral(resourceName: "IMG_0012.PNG")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.delegate = self
        self.title = "miPhotos"
        self.collectionView?.backgroundColor = .white
        self.collectionView?.register(MyCollectionViewCell.self, forCellWithReuseIdentifier: "PlayCell")
        
        //Botão na Bar para adicionar foto da Libray
        let AddBtn = UIButton(type: .custom)
        AddBtn.setTitle("ADD", for: .normal)
        AddBtn.titleLabel?.font = UIFont (name: "helvetica", size: 17)
        AddBtn.setTitleColor(AddBtn.tintColor, for: .normal) 
        AddBtn.addTarget(self, action: #selector(addPhoto(sender:)), for: .touchUpInside)
        
        //Botão na Bar para acessar a camera
        let CamBtn = UIBarButtonItem (barButtonSystemItem: UIBarButtonSystemItem, target: <#T##Any?#>, action: <#T##Selector?#>)// UIButton(type: .custom)
        CamBtn.setTitle("📷", for: .normal)
        CamBtn.titleLabel?.font = UIFont (name: "helvetica", size: 17)
        CamBtn.setTitleColor(CamBtn.tintColor, for: .normal) 
        CamBtn.addTarget(self, action: #selector(takePhoto(sender:)), for: .touchUpInside)
        
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: AddBtn)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: CamBtn)
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        return CGSize(width: 150, height: 150)
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photoList.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayCell", for: indexPath) as! MyCollectionViewCell
        
        // UIControlerViewCells does not have viewDidLoad method, so we have to set the value directly into the element (nameLabel in this case). It is not usual.
        cell.button.image = photoList[indexPath.row]
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let profileCell = collectionView.cellForItem(at: indexPath) as! MyCollectionViewCell
        let profileViewController = ProfileViewController()
        profileViewController.imagem  = profileCell.button.image!
        profileViewController.backgroundColor = profileCell.backgroundColor!
        navigationController?.pushViewController(profileViewController, animated: true)
    }
    //Controla o Picker da Foto --> Adiciona a foto do picker no array de fotos
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [String : Any])
    {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        photoList.append(chosenImage)
        
        DispatchQueue.main.async {
            self.collectionView?.reloadData()


        }
        dismiss(animated:true, completion: nil) 
    }
    
    // @IBA func que accessa a libraria de fotos para adicioná-la
    @IBAction func addPhoto(sender:UIButton) {
        
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
        
        }
    
    //Acesso a camera
    @IBAction func takePhoto(sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }else{
            let alert = UIAlertController(title: "Ops!", message: "No Camera found!", preferredStyle: .alert)
            
            let OkBtn = UIAlertAction(title: "Ok", style: .cancel, handler: <#T##((UIAlertAction) -> Void)?##((UIAlertAction) -> Void)?##(UIAlertAction) -> Void#>)
        }
    }
    
    //Fecha a View do Picker
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
}

PlaygroundPage.current.liveView = UINavigationController(rootViewController:CollectionViewController(collectionViewLayout: UICollectionViewFlowLayout()))



